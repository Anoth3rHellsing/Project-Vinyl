﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using NAudio.CoreAudioApi.Interfaces;
using NAudio.MediaFoundation;
using NAudio.Utils;

namespace NAudioWpfDemo.MediaFoundationEncode;

internal class MediaTypeViewModel
{
    public MediaTypeViewModel()
    {

    }

    public MediaTypeViewModel(MediaType mediaType)
    {
        MediaType = mediaType;
        Name = ShortDescription(mediaType);
        Description = DescribeMediaType(mediaType);
    }

    public MediaType MediaType { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }

    private string ShortDescription(MediaType mediaType)
    {
        Guid subType = mediaType.SubType;
        int sampleRate = mediaType.SampleRate;
        int bytesPerSecond = mediaType.AverageBytesPerSecond;
        int channels = mediaType.ChannelCount;
        int bitsPerSample = mediaType.TryGetUInt32(MediaFoundationAttributes.MF_MT_AUDIO_BITS_PER_SAMPLE);

        var shortDescription = new StringBuilder();
        shortDescription.AppendFormat("{0:0.#}kbps, ", (8 * bytesPerSecond) / 1000M);
        shortDescription.AppendFormat("{0:0.#}kHz, ", sampleRate / 1000M);
        if (bitsPerSample != -1)
            shortDescription.AppendFormat("{0} bit, ", bitsPerSample);
        shortDescription.AppendFormat("{0}, ", channels == 1 ? "mono" : channels == 2 ? "stereo" : channels.ToString() + " channels");
        if (subType == AudioSubtypes.MFAudioFormat_AAC)
        {
            int payloadType = mediaType.TryGetUInt32(MediaFoundationAttributes.MF_MT_AAC_PAYLOAD_TYPE);
            if (payloadType != -1)
                shortDescription.AppendFormat("Payload Type: {0}, ", (AacPayloadType)payloadType);
        }
        shortDescription.Length -= 2;
        return shortDescription.ToString();
    }

    private string DescribeMediaType(MediaType mediaType)
    {
        int attributeCount = mediaType.AttributeCount;
        var sb = new StringBuilder();
        for (int n = 0; n < attributeCount; n++)
        {
            DescribeAttribute(mediaType, n, sb);
        }
        return sb.ToString();
    }

    private static void DescribeAttribute(MediaType mediaType, int n, StringBuilder sb)
    {
        var variantPtr = Marshal.AllocHGlobal(Marshal.SizeOf<PropVariant>());
        try
        {
            mediaType.GetAttributeByIndex(n, out var key, variantPtr);
            var val = Marshal.PtrToStructure<PropVariant>(variantPtr);
            string propertyName = FieldDescriptionHelper.Describe(typeof(MediaFoundationAttributes), key);
            sb.AppendFormat("{0}={1}\r\n", propertyName, val.Value);
        }
        finally
        {
            PropVariant.Clear(variantPtr);
            Marshal.FreeHGlobal(variantPtr);
        }
    }
}
